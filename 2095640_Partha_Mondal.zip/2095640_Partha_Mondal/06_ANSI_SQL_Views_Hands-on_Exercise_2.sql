select student_name, registration_number,GPA from student_marks
order by GPA desc;

select * from student_info
order by Stu_Name asc;

select * from student_info
order by Stu_Age asc;

select registration_number, student_name, semester_number,GPA from student_result
order by GPA desc;

select registration_number, student_name, semester_number,GPA from student_result
order by GPA desc;

select * from student_result
group by Semester
having max(GPA);

select * from student_result
group by Semester
having min(GPA);