select upper(Student_name) from student_info;
select upper(Student_branch) from student_info;

select lower(Subject_Code) from subject_master;
select lower(Subject_Name) from subject_master;
select lower(Wei_for_GPA) from subject_master;

select concat('Age =', floor((current_date - Date_of_Birth)/4380))  from student_info;

select reg_number, student_name,avg(marks) from student_result;

select reg_number, student_name,max(marks) from student_result;

select reg_number, student_name, max(marks ) from student_marks
where subject_name='EI05IP';

SELECT *, ISNULL(base_fees,0) FROM module_info;

