Select sum(No_of_associates),start_date from associate_info
group by start_date;

Select sum(No_of_associates),start_date from associate_info
where trainer_id='F001'
group by start_date;

Select sum(No_of_associates),start_date from associate_info
where trainer_id='F001'
group by start_date
having sum(No_of_associates)>2;

select * from module_info
order by module_duration;

select associates_name,module_name,module_id, base_fees from module_info, associate_info, fees
order by fees.base_fees desc;