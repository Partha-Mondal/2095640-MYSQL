insert into Course_Info values('343','Java Programming','Basics of java',"2012-12-12");
select * from Course_Info;
insert into Course_Info values('167','C Programming','Basics of C',"2012-11-11");
insert into Course_Info values('106','ORACLE','ORACLE SQL',"2011-03-11");
