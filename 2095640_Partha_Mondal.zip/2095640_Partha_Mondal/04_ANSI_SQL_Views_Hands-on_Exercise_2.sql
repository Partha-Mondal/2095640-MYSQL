SELECT * FROM student_info
where Enail_id is not null;

select Reg_Number, marks from student_marks
where marks>=70;

select si.Reg_Number,si.Student_Name, sm.Subject_Code, sm.Semester, sm.marks,smt.Subject_name from student_info
as s1 inner join student_marks as sm on si.Red_Number =sm.Reg_Number
inner join subject_master as smt on smt.Subject_Code = sm.Subject_Code;

select si.Reg_Number,si.Student_Name, sm.Subject_Code, sm.Semester, sm.marks,smt.Subject_name from student_info
as si inner join student_marks as sm on si.Red_Number =sm.Reg_Number
inner join subject_master as smt on smt.Subject_Code = sm.Subject_Code
where sm.marks>70;

select * from student_result
order by Is_Eligible Desc;

select si.Reg_Number,si.Student_Name, sm.Subject_Code, sm.Semester, sm.marks,smt.Weightage
as "Weightage_marks= " from student_info as si inner join student_marks as sm on 
si.Regestration_no= sm. Reg_Number inner join subject_master as smt on smt.Subject_Code= sm. Subject_Code;

select student_name, reg_number from student_info
where student_name like 'M%';
