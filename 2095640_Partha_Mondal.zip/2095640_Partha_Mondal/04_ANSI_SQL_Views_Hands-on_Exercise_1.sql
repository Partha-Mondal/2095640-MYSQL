Select * from trainer_info
where Trainer_Email= null;

Select Trainer_Id,Trainer_Name,Trainer_Track,Trainer_location from trainer_info
where Trainer_Experiance >4;

SELECT * FROM module_info
where Module_Duration>200;

Select Trainer_Id,Trainer_Name from trainer_info
where Trainer_Qualification<>'Bachelor of Technology';

select * from module_info
where Module_Duration between 200 and 300;

Select Trainer_Id,Trainer_Name from trainer_info
where Trainer_Name like'M%';

Select Trainer_Id,Trainer_Name from trainer_info
where Trainer_Name like'%O%';

select * from module_info
where Module_Name <> null;