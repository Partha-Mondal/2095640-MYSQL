CREATE VIEW v1 AS
SELECT associate_ID ,trainer_ID,batch_ID
FROM associate_status;

CREATE VIEW v2 AS
SELECT associate_ID ,trainer_ID,batch_ID
FROM associate_status
WHERE Batch_Id='B004';

DROP VIEW v2;

CREATE INDEX I1 ON associate_info (associate_name);

CREATE unique INDEX I2 ON associate_info (associate_name);

drop index I1 on associate_info;


CREATE VIEW v3 AS
SELECT associate_ID ,trainer_ID,batch_ID
FROM associate_status
WITH CASCADED CHECK OPTION;

CREATE VIEW v3 AS
SELECT associate_ID ,trainer_ID,batch_ID
FROM associate_status
WITH LOCAL CHECK OPTION;