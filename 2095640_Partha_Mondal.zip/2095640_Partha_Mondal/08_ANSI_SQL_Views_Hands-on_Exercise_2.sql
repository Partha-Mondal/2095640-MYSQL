select si.Regestration_no, si.Stu_Name from student_info si
inner join student_marks as sm on si.Regestration_no=sm.Reg_Number
where  sm.marks in (select max(marks)
                     from student_marks as sm);
					

select si.Regestration_no, si.Stu_Name from student_info si
inner join student_marks as sm on si.Regestration_no=sm.Reg_number
where  sm.marks = (select avg(marks)from student_marks as sm where  Subject_code='EI05IP');


select si.Regestration_no, si.Stu_Name from student_info si
inner join student_marks as sm on si.Regestration_no=sm.Reg_number
where ( sm.marks = (select marks from student_marks as sm where  Subject_code='EI05IP' order by marks desc limit 1,1)and Subject_code= 'EI05IP');



select si.Regestration_no, si.Stu_Name from student_info si
inner join student_marks as sm on si.Regestration_no=sm.Reg_number
where (marks > (select avg(marks) from student_marks where Subject_Code='EI05IP'));

