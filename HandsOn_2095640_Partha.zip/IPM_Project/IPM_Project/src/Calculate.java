
public class Calculate {

}
