
public class Square {

	public static void main(String[] args) {
		int area= claculatearea(20);
		System.out.println("The are is:"+area);

	}

	private static int claculatearea(int i) {
		int area=i*i;
		return area;
	}

}
